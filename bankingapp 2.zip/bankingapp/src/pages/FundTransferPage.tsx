import axios from "axios";
import { useForm } from "react-hook-form";
import { Link, useNavigate } from "react-router-dom";
import { useContext, useEffect, useState } from "react";
import { IFundTransfer } from "../models/IFundTransfer";
//import { CartContext, CartContextProps } from "../contexts/CartContext";

const FundTransferPage = () => {
    return (
        <div>
            <h1>Transfer funds</h1>
            <form
                className="col-md-6 offset-md-3"
            >
                <div className="form-group row mb-3">
                <label className="col-sm-2 col-form-label" htmlFor="nameInput">
                    source account
                </label>
                <div className="col-sm-10">
                    <input
                    type="text"
                    id="nameInput"
                    className="form-control"
                    placeholder="Enter Name"
                    />

                </div>
                </div>
                <div className="form-group row mb-3">
                <label htmlFor="amount" className="col-sm-2 col-form-label">
                    target account
                </label>
                <div className="col-sm-10">
                    <input
                    type="text"
                    id="amount"
                    className="form-control"
                    placeholder="Enter amount"
                    />
                </div>
                </div>

        <div className="form-group row">
          <div className="col-sm-10 offset-sm-2">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        </div>
      </form>
    </div>
    );
}

export default FundTransferPage;