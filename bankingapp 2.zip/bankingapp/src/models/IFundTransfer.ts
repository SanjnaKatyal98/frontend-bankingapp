export interface IFundTransfer {
    id: number;
    sourceAcc: number;
    targetAcc: number;
    amount: number;
  }
  