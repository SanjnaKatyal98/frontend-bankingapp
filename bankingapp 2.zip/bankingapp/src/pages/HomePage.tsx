import { Link } from "react-router-dom";

const HomePage = () => {
  return (
    <div className="px-4 py-5 my-5 text-center">
      <h1 className="display-5 fw-bold text-body-emphasis">
        Welcome to Banking App
      </h1>
      <div className="col-lg-6 mx-auto">
        <p className="lead mb-4">
          Banking application is one stop solution to manage different types of
          banking account with the ease of doing deposit,withdrawl and fund
          transfer. get various benefits by creating account today
        </p>
        <div className="d-grid gap-2 d-sm-flex justify-content-sm-center">
          <Link to="#" className="btn btn-primary btn-lg px-4 gap-3">
            Browse Accounts
          </Link>
          <Link to="#" className="btn btn-secondary btn-lg px-4">
            fund transfer
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
