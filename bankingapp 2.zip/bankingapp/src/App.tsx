import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import logo from './logo.svg';
import './App.css';
import Header from './layouts/Header';
import Footer from './layouts/Footer';
import { BrowserRouter } from 'react-router-dom';
import { CartProvider } from './contexts/CartContext';
import MainRoutes from './routes/MainRoutes';

function App() {
  return (
    <BrowserRouter>
      <CartProvider>
        <Header />
        <main className="container mt-5 pt-3">
          <MainRoutes />
        </main>
        <Footer />
      </CartProvider>
    </BrowserRouter>
  );
}

export default App;
