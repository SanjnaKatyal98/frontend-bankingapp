export interface IAccount {
    id: number;
    name: string;
    amount: number;
    roi: number;
  }
  