import axios from "axios";
import { useForm } from "react-hook-form";
import { Link, useNavigate } from "react-router-dom";
import { useContext, useEffect, useState } from "react";
import { IAccount } from "../models/IAccount";
//import { CartContext, CartContextProps } from "../contexts/CartContext";

const AccountPage = () => {
    return (
        <div>
            <h1>Add Account</h1>
            <form
                className="col-md-6 offset-md-3"
            >
                <div className="form-group row mb-3">
                <label className="col-sm-2 col-form-label" htmlFor="nameInput">
                    Name
                </label>
                <div className="col-sm-10">
                    <input
                    type="text"
                    id="nameInput"
                    className="form-control"
                    placeholder="Enter Name"
                    />

                </div>
                </div>
                <div className="form-group row mb-3">
                <label htmlFor="amount" className="col-sm-2 col-form-label">
                    Amount
                </label>
                <div className="col-sm-10">
                    <input
                    type="text"
                    id="amount"
                    className="form-control"
                    placeholder="Enter amount"
                    />
                </div>
                </div>

        <div className="form-group row">
          <div className="col-sm-10 offset-sm-2">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        </div>
      </form>
    </div>
    );
}

export default AccountPage;