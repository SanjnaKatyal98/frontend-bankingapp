export interface ITransaction {
    id: number;
    descp: string;
    amount: number;
  }
  