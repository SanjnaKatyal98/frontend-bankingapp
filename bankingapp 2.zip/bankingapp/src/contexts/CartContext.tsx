import { createContext, useState } from "react";
import { IProduct } from "../models/IProduct";

export interface CartContextProps {
  cartItems: IProduct[]; // Needed for Header, ProductsPage
  addToCart: (cartItems: IProduct[]) => void; // Needed for ProductsPage
}

export const CartContext = createContext<CartContextProps | undefined>(
  undefined
);

export const CartProvider = ({ children }: { children: React.ReactNode }) => {
  const [cartItems, setCartItems] = useState<IProduct[]>([]);

  return (
    <CartContext.Provider
      value={{ cartItems: cartItems, addToCart: setCartItems }}
    >
      {children}
    </CartContext.Provider>
  );
};
